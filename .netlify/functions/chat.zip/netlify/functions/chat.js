// HSD OS AI — Claude chat proxy with server-side rate limiting via Firestore REST API
const Anthropic = require("@anthropic-ai/sdk");

const PROJECT_ID = process.env.VITE_FIREBASE_PROJECT_ID || "hear-see-do-os-ai";

// Daily message limits per plan
const PLAN_LIMITS = {
  individual:    5,
  kids_starter:  15,
  english_boost: 15,
  adult_growth:  30,
  family_full:   30,
  all_access:    100, // marketed as unlimited — 100 is the hidden safety cap
};

function todayJST() {
  return new Date().toLocaleDateString("en-CA", { timeZone: "Asia/Tokyo" }); // YYYY-MM-DD
}

async function firestoreGet(path, idToken) {
  const url = `https://firestore.googleapis.com/v1/projects/${PROJECT_ID}/databases/(default)/documents/${path}`;
  const res  = await fetch(url, {
    headers: idToken ? { Authorization: `Bearer ${idToken}` } : {},
  });
  if (!res.ok) return null;
  return res.json();
}

async function firestorePatch(path, fields, idToken) {
  const fieldPaths = Object.keys(fields).join("&updateMask.fieldPaths=");
  const url = `https://firestore.googleapis.com/v1/projects/${PROJECT_ID}/databases/(default)/documents/${path}?updateMask.fieldPaths=${fieldPaths}`;
  const body = {
    fields: Object.fromEntries(
      Object.entries(fields).map(([k, v]) => [k, { integerValue: String(v) }])
    ),
  };
  const res = await fetch(url, {
    method:  "PATCH",
    headers: {
      "Content-Type": "application/json",
      ...(idToken ? { Authorization: `Bearer ${idToken}` } : {}),
    },
    body: JSON.stringify(body),
  });
  return res.ok;
}

async function verifyIdToken(idToken) {
  // Firebase Auth REST — verify ID token and return uid + email
  const url = `https://identitytoolkit.googleapis.com/v1/accounts:lookup?key=${process.env.VITE_FIREBASE_API_KEY}`;
  const res  = await fetch(url, {
    method:  "POST",
    headers: { "Content-Type": "application/json" },
    body:    JSON.stringify({ idToken }),
  });
  if (!res.ok) return null;
  const data = await res.json();
  return data.users?.[0] ?? null;
}

exports.handler = async (event) => {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: JSON.stringify({ error: "Method not allowed" }) };
  }

  let body;
  try { body = JSON.parse(event.body); }
  catch { return { statusCode: 400, body: JSON.stringify({ error: "Invalid JSON" }) }; }

  const { system, messages, idToken, plan = "individual" } = body;

  // ── Rate limit check ──────────────────────────────────────────────────────
  if (idToken) {
    try {
      const firebaseUser = await verifyIdToken(idToken);
      if (firebaseUser) {
        const uid   = firebaseUser.localId;
        const today = todayJST();
        const limit = PLAN_LIMITS[plan] ?? PLAN_LIMITS.individual;
        const docPath = `users/${uid}/chatUsage/${today}`;

        const doc   = await firestoreGet(docPath, idToken);
        const count = doc?.fields?.count
          ? parseInt(doc.fields.count.integerValue ?? doc.fields.count.doubleValue ?? 0)
          : 0;

        if (count >= limit) {
          const planLabel = plan === "all_access" ? "100 (daily safety limit)" : String(limit);
          return {
            statusCode: 429,
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              error:     "daily_limit_reached",
              count,
              limit,
              message:   plan === "all_access"
                ? `You've reached today's message limit. It resets at midnight Japan time.`
                : `You've used all ${planLabel} messages for today. Upgrade your plan for more daily conversations.`,
              resetTime: "midnight JST",
            }),
          };
        }

        // Increment count
        await firestorePatch(docPath, { count: count + 1 }, idToken);
      }
    } catch (e) {
      // Rate limit check failed — allow the message through rather than blocking legitimate users
      console.error("Rate limit check error:", e.message);
    }
  }

  // ── Claude API call ───────────────────────────────────────────────────────
  const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

  try {
    const response = await client.messages.create({
      model:      "claude-sonnet-4-6",
      max_tokens: 512,
      system,
      messages,
    });

    return {
      statusCode: 200,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ content: response.content[0].text }),
    };
  } catch (err) {
    console.error("Claude error:", err.message);
    return { statusCode: 500, body: JSON.stringify({ error: err.message }) };
  }
};
