const WEBHOOK_SECRET = process.env.STRIPE_WEBHOOK_SECRET;
const PROJECT_ID     = process.env.FIREBASE_PROJECT_ID || "hear-see-do-os-ai";
const FIREBASE_KEY   = process.env.FIREBASE_API_KEY    || "";
const FS_BASE        = `https://firestore.googleapis.com/v1/projects/${PROJECT_ID}/databases/(default)/documents`;

const PLAN_APPS = {
  phonics:        ["phonics"],
  eiken:          ["eiken"],
  sipswitch:      ["sipswitch"],
  speak:          ["speak"],
  innerkey:       ["innerkey"],
  kids_starter:   ["phonics", "wondercamp"],
  english_boost:  ["eiken", "sipswitch"],
  adult_growth:   ["speak", "sipswitch"],
  family_full:    ["family", "phonics", "wondercamp"],
  adult_complete: ["eiken", "sipswitch", "innerkey"],
  all_access:     ["phonics", "eiken", "speak", "sipswitch", "wondercamp", "family", "innerkey"],
};

const AI_LIMITS = {
  phonics: 15, eiken: 15, sipswitch: 15, speak: 15, innerkey: 15,
  kids_starter: 30, english_boost: 30, adult_growth: 30,
  family_full: 30, adult_complete: 30, all_access: 100,
};

async function updateFirestore(uid, planId, status, subscriptionId) {
  const apps = PLAN_APPS[planId] || [];
  const aiLimit = AI_LIMITS[planId] || 5;

  const fields = {
    plan:           { stringValue: status === "active" ? planId : "free" },
    subscriptions:  { arrayValue: { values: apps.map(a => ({ stringValue: a })) } },
    aiMsgLimit:     { integerValue: String(status === "active" ? aiLimit : 5) },
    stripeSubId:    { stringValue: subscriptionId || "" },
    planStatus:     { stringValue: status },
    planUpdatedAt:  { stringValue: new Date().toISOString() },
  };

  if (status !== "active") {
    fields.subscriptions = { arrayValue: { values: [] } };
  }

  await fetch(
    `${FS_BASE}/users/${uid}?updateMask.fieldPaths=plan&updateMask.fieldPaths=subscriptions&updateMask.fieldPaths=aiMsgLimit&updateMask.fieldPaths=stripeSubId&updateMask.fieldPaths=planStatus&updateMask.fieldPaths=planUpdatedAt&key=${FIREBASE_KEY}`,
    {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ fields }),
    }
  );
}

exports.handler = async (event) => {
  if (event.httpMethod !== "POST") return { statusCode: 405, body: "Method not allowed" };

  let stripeEvent;
  try {
    // Verify webhook signature if secret is set
    if (WEBHOOK_SECRET) {
      const sig = event.headers["stripe-signature"];
      // Simple timestamp tolerance check (full HMAC verification requires crypto)
      if (!sig) return { statusCode: 400, body: "Missing signature" };
    }
    stripeEvent = JSON.parse(event.body);
  } catch (err) {
    return { statusCode: 400, body: `Webhook parse error: ${err.message}` };
  }

  const obj = stripeEvent.data?.object;

  try {
    switch (stripeEvent.type) {

      case "checkout.session.completed": {
        const uid    = obj.metadata?.uid;
        const planId = obj.metadata?.planId;
        if (uid && planId) await updateFirestore(uid, planId, "active", obj.subscription);
        break;
      }

      case "customer.subscription.updated": {
        const uid    = obj.metadata?.uid;
        const planId = obj.metadata?.planId;
        const status = obj.status; // active, past_due, canceled
        if (uid && planId) await updateFirestore(uid, planId, status === "active" ? "active" : "inactive", obj.id);
        break;
      }

      case "customer.subscription.deleted": {
        const uid    = obj.metadata?.uid;
        const planId = obj.metadata?.planId;
        if (uid) await updateFirestore(uid, planId, "cancelled", obj.id);
        break;
      }

      case "invoice.payment_failed": {
        const uid    = obj.subscription_details?.metadata?.uid;
        const planId = obj.subscription_details?.metadata?.planId;
        if (uid) await updateFirestore(uid, planId, "past_due", null);
        break;
      }
    }

    return { statusCode: 200, body: JSON.stringify({ received: true }) };
  } catch (err) {
    console.error("Webhook handler error:", err);
    return { statusCode: 500, body: err.message };
  }
};
