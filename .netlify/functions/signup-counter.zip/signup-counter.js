// Shared signup counter stored in Firestore meta/signups
// GET  → returns { count, spotsLeft }
// POST → increments count, returns { count, spotsLeft }

const PROJECT_ID = process.env.FIREBASE_PROJECT_ID || "hear-see-do-os-ai";
const API_KEY    = process.env.FIREBASE_API_KEY    || "";
const FS_BASE    = `https://firestore.googleapis.com/v1/projects/${PROJECT_ID}/databases/(default)/documents`;
const DOC_URL    = `${FS_BASE}/meta/signups`;
const TOTAL_SPOTS = 200;

async function getCount() {
  const res = await fetch(`${DOC_URL}?key=${API_KEY}`);
  if (res.status === 404) return 0;
  if (!res.ok) throw new Error(`Firestore read failed: ${res.status}`);
  const data = await res.json();
  return parseInt(data.fields?.count?.integerValue ?? "0", 10);
}

async function setCount(count) {
  const res = await fetch(`${DOC_URL}?updateMask.fieldPaths=count&key=${API_KEY}`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ fields: { count: { integerValue: String(count) } } }),
  });
  if (!res.ok) throw new Error(`Firestore write failed: ${res.status}`);
}

const CORS = {
  "Access-Control-Allow-Origin":  "*",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
};

exports.handler = async (event) => {
  if (event.httpMethod === "OPTIONS") return { statusCode: 204, headers: CORS };

  try {
    if (event.httpMethod === "GET") {
      const count = await getCount();
      return {
        statusCode: 200,
        headers: { ...CORS, "Content-Type": "application/json" },
        body: JSON.stringify({ count, spotsLeft: Math.max(0, TOTAL_SPOTS - count) }),
      };
    }

    if (event.httpMethod === "POST") {
      const current = await getCount();
      if (current >= TOTAL_SPOTS) {
        return {
          statusCode: 200,
          headers: { ...CORS, "Content-Type": "application/json" },
          body: JSON.stringify({ count: current, spotsLeft: 0, full: true }),
        };
      }
      const next = current + 1;
      await setCount(next);
      return {
        statusCode: 200,
        headers: { ...CORS, "Content-Type": "application/json" },
        body: JSON.stringify({ count: next, spotsLeft: Math.max(0, TOTAL_SPOTS - next), spotNumber: next }),
      };
    }

    return { statusCode: 405, headers: CORS, body: "Method not allowed" };
  } catch (err) {
    console.error("signup-counter error:", err);
    // Fail open — don't block the signup flow
    return {
      statusCode: 200,
      headers: { ...CORS, "Content-Type": "application/json" },
      body: JSON.stringify({ count: 0, spotsLeft: TOTAL_SPOTS, error: err.message }),
    };
  }
};
